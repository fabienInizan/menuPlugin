<?php
	return array(
		'modules'=>'menu',
		'templates/admin'=>'menu',
		'templates/public'=>'menu'
	);
?>
