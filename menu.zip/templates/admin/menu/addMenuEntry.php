<ul class="context_menu">
	<li><a href="index.php?module=menu&action=display&menuId=<?php echo $menuEntry->getMenuId(); ?>">Retour au menu</a></li>
</ul>

<p>L'entrée a été ajoutée avec succès au menu !</p>
