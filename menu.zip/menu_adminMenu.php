<?php
	return array(	'title'=>'Menus',
			'description'=>'Gérez les menus du site',
			'link'=>'?module=menu&action=index'
	);
?>
