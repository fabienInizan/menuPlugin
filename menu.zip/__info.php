<?php
	return array(
		'id'=>'menu',
		'title'=>'Menu',
		'description'=>'Gérez les menus de votre site.',
		'version'=>'1.0',
		'date'=>'2012-09-11'
	);
?>
